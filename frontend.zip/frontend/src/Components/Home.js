import React from 'react'
import { Link } from 'react-router-dom'

const Home = () => {
  return (
    <div className="home-container">
      <h1 className="home-title">Welcome to the Home Page</h1>
      <p className="home-desc">This is the main landing page of our application.</p>
      <div className="home-actions">
        <Link to="/signup">Get Started</Link>
        <Link to="/aboutus">Learn More</Link>
      </div>
    </div>
  )
}

export default Home
