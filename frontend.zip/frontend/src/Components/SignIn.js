import React, { useState } from 'react';

const SignIn = () => {
  const [form, setForm] = useState({ username: '', password: '' });

  const styles = {
    container: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #e0e7ff 0%, #f8fafc 100%)',
      padding: '20px',
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      width: '340px',
      backgroundColor: '#fff',
      padding: '32px 28px',
      borderRadius: '16px',
      boxShadow: '0 8px 32px rgba(60, 72, 88, 0.12)',
      animation: 'fadeInSignIn 1s',
    },
    input: {
      width: '100%',
      padding: '12px',
      margin: '12px 0',
      borderRadius: '6px',
      border: '1px solid #c7d2fe',
      fontSize: '16px',
      outline: 'none',
      transition: 'border-color 0.2s',
    },
    button: {
      width: '100%',
      padding: '12px',
      margin: '16px 0 0 0',
      borderRadius: '6px',
      border: 'none',
      background: 'linear-gradient(90deg, #6366f1 0%, #4f46e5 100%)',
      color: '#fff',
      fontSize: '17px',
      fontWeight: 'bold',
      cursor: 'pointer',
      boxShadow: '0 2px 8px rgba(99,102,241,0.08)',
      transition: 'background 0.3s, transform 0.2s',
    },
    label: {
      margin: '6px 0 2px 0',
      fontSize: '15px',
      color: '#4f46e5',
      fontWeight: 'bold',
      alignSelf: 'flex-start',
    },
    title: {
      color: '#4f46e5',
      marginBottom: '18px',
      fontSize: '2rem',
      fontWeight: 'bold',
      letterSpacing: '1px',
      textAlign: 'center',
    },
  };

  React.useEffect(() => {
    const styleSheet = document.createElement("style");
    styleSheet.innerText = `
      @keyframes fadeInSignIn {
        from { opacity: 0; transform: translateY(40px);}
        to { opacity: 1; transform: translateY(0);}
      }
      .signin-input:focus {
        border-color: #6366f1 !important;
        box-shadow: 0 0 0 2px #6366f133;
      }
      .signin-btn:hover {
        background: linear-gradient(90deg, #4f46e5 0%, #6366f1 100%) !important;
        transform: translateY(-2px) scale(1.03);
      }
    `;
    document.head.appendChild(styleSheet);
    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    // Send credentials to backend for verification
    try {
      const res = await fetch('http://localhost:3000/api/users/signin', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok && data.success) {
        window.alert('Sign in successful!');
      } else {
        window.alert('Username or password is incorrect.');
        setForm({ username: '', password: '' }); // Reset form on error
      }
    } catch (err) {
      window.alert('Server error. Please try again later.');
    }
  };

  return (
    <div style={styles.container}>
      <form style={styles.form} autoComplete="off" onSubmit={handleSubmit}>
        <div style={styles.title}>Sign In</div>
        <label style={styles.label} htmlFor="username">Username</label>
        <input
          className="signin-input"
          style={styles.input}
          type="text"
          name="username"
          value={form.username}
          onChange={handleChange}
          placeholder="Enter your username"
          id="username"
          required
        />
        <label style={styles.label} htmlFor="password">Password</label>
        <input
          className="signin-input"
          style={styles.input}
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          placeholder="Enter your password"
          id="password"
          required
        />
        <button
          className="signin-btn"
          style={styles.button}
          type="submit"
        >
          Sign In
        </button>
      </form>
    </div>
  );
};

export default SignIn;
