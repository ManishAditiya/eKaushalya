import React from 'react'
import { Link, Outlet } from 'react-router-dom'

const Layout = () => (
  <div>
    <header className="main-header">
      <div className="logo">Kaushalya</div>
      <nav className="main-nav">
        <Link to="/">Home</Link>
        <Link to="/aboutus">About Us</Link>
        <Link to="/signin">Sign In</Link>
        <Link to="/signup">Sign Up</Link>
      </nav>
    </header>
    <Outlet />
  </div>
)

export default Layout