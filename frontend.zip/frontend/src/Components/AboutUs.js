import React from 'react'
import { Link } from 'react-router-dom'
import './AboutUs.css' // Import the CSS file

const AboutUs = () => {
  return (
    <div className="aboutus-container">
      <h1 className="aboutus-title">About Us</h1>
      <nav className="aboutus-nav">
        <Link to="/signin">Sign In</Link>
        <span className="aboutus-separator">|</span>
        <Link to="/signup">Sign Up</Link>
      </nav>
      <p className="aboutus-desc">We are a company dedicated to providing the best services to our customers.</p>
      <p className="aboutus-desc">Our mission is to deliver high-quality products and exceptional customer service.</p>
      <p className="aboutus-contact">
        Contact us at: <a href="mailto:info@company.com">info@company.com</a>
      </p>
      <p className="aboutus-social-title">Follow us on social media:</p>
      <ul className="aboutus-social-list">
        <li><a href="https://twitter.com/company" target="_blank" rel="noopener noreferrer">Twitter</a></li>
        <li><a href="https://facebook.com/company" target="_blank" rel="noopener noreferrer">Facebook</a></li>
        <li><a href="https://instagram.com/company" target="_blank" rel="noopener noreferrer">Instagram</a></li>
      </ul>
      <p className="aboutus-thankyou">Thank you for visiting our website!</p>
      <p className="aboutus-footer">We look forward to serving you.</p>
      <p className="aboutus-copyright">© 2023 Company Name. All rights reserved.</p>
    </div>
  )
}

export default AboutUs
