import React, { useState } from 'react';

const SignUp = () => {
  const [form, setForm] = useState({
    username: '',
    email: '',
    password: '',
    confirmPassword: ''
  });
  const [message, setMessage] = useState('');

  const styles = {
    container: {
      minHeight: '100vh',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      justifyContent: 'center',
      background: 'linear-gradient(135deg, #e0e7ff 0%, #f8fafc 100%)',
      padding: '20px',
    },
    header: {
      fontSize: '2rem',
      marginBottom: '20px',
      color: '#4f46e5',
      fontWeight: 'bold',
      letterSpacing: '1px',
      textAlign: 'center',
    },
    form: {
      display: 'flex',
      flexDirection: 'column',
      width: '340px',
      backgroundColor: '#fff',
      padding: '32px 28px',
      borderRadius: '16px',
      boxShadow: '0 8px 32px rgba(60, 72, 88, 0.12)',
      animation: 'fadeInSignUp 1s',
    },
    label: {
      marginBottom: '5px',
      fontSize: '15px',
      color: '#4f46e5',
      fontWeight: 'bold',
      alignSelf: 'flex-start',
    },
    input: {
      width: '100%',
      padding: '12px',
      marginBottom: '15px',
      borderRadius: '6px',
      border: '1px solid #c7d2fe',
      fontSize: '16px',
      outline: 'none',
      transition: 'border-color 0.2s',
    },
    button: {
      width: '100%',
      padding: '12px',
      borderRadius: '6px',
      border: 'none',
      background: 'linear-gradient(90deg, #6366f1 0%, #4f46e5 100%)',
      color: '#fff',
      fontSize: '17px',
      fontWeight: 'bold',
      cursor: 'pointer',
      boxShadow: '0 2px 8px rgba(99,102,241,0.08)',
      transition: 'background 0.3s, transform 0.2s',
      marginTop: '8px',
    },
    message: {
      margin: '12px 0',
      color: '#16a34a',
      textAlign: 'center',
      fontWeight: 'bold',
    },
    error: {
      margin: '12px 0',
      color: '#dc2626',
      textAlign: 'center',
      fontWeight: 'bold',
    }
  };

  React.useEffect(() => {
    const styleSheet = document.createElement("style");
    styleSheet.innerText = `
      @keyframes fadeInSignUp {
        from { opacity: 0; transform: translateY(40px);}
        to { opacity: 1; transform: translateY(0);}
      }
      .signup-input:focus {
        border-color: #6366f1 !important;
        box-shadow: 0 0 0 2px #6366f133;
      }
      .signup-btn:hover {
        background: linear-gradient(90deg, #4f46e5 0%, #6366f1 100%) !important;
        transform: translateY(-2px) scale(1.03);
      }
    `;
    document.head.appendChild(styleSheet);
    return () => {
      document.head.removeChild(styleSheet);
    };
  }, []);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setMessage('');
    if (form.password !== form.confirmPassword) {
      setMessage('Passwords do not match.');
      return;
    }
    try {
      const res = await fetch('http://localhost:3000/api/users', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: form.username,
          email: form.email,
          password: form.password
        })
      });
      if (res.ok) {
        setMessage('Registration successful!');
        setForm({ username: '', email: '', password: '', confirmPassword: '' });
      } else {
        const data = await res.json();
        setMessage(data.message || 'Registration failed.');
      }
    } catch (err) {
      setMessage('Server error. Please try again later.');
    }
  };

  return (
    <div style={styles.container}>
      <h1 style={styles.header}>Sign Up</h1>
      <form style={styles.form} autoComplete="off" onSubmit={handleSubmit}>
        <label style={styles.label} htmlFor="username">Username</label>
        <input
          className="signup-input"
          style={styles.input}
          type="text"
          name="username"
          value={form.username}
          onChange={handleChange}
          placeholder="username"
          id="username"
          required
        />
        <label style={styles.label} htmlFor="email">Email</label>
        <input
          className="signup-input"
          style={styles.input}
          type="email"
          name="email"
          value={form.email}
          onChange={handleChange}
          placeholder="email"
          id="email"
          required
        />
        <label style={styles.label} htmlFor="create-password">Create Password</label>
        <input
          className="signup-input"
          style={styles.input}
          type="password"
          name="password"
          value={form.password}
          onChange={handleChange}
          placeholder="create password"
          id="create-password"
          required
        />
        <label style={styles.label} htmlFor="confirm-password">Confirm Password</label>
        <input
          className="signup-input"
          style={styles.input}
          type="password"
          name="confirmPassword"
          value={form.confirmPassword}
          onChange={handleChange}
          placeholder="confirm password"
          id="confirm-password"
          required
        />
        <button
          className="signup-btn"
          style={styles.button}
          type="submit"
        >
          Sign Up
        </button>
        {message && (
          <div style={message === 'Registration successful!' ? styles.message : styles.error}>
            {message}
          </div>
        )}
      </form>
    </div>
  );
};

export default SignUp;
